import os
import logging
from mutagen.id3 import ID3, POPM, TXXX, COMM
from mutagen.mp3 import MP3

logger = logging.getLogger(__name__)

def write_metadata_to_file(file_path: str, rating: float = None, mood: str = None):
    """
    Writes rating and mood directly to the MP3 file ID3 tags.
    This ensures data persistence even if the database is lost.
    """
    if not os.path.exists(file_path):
        logger.error(f"File not found for tagging: {file_path}")
        return False
        
    try:
        audio = MP3(file_path, ID3=ID3)
        
        # 1. Write Rating (0-5 stars -> 0-255 uint)
        if rating is not None:
            # Scale 0-5 to 0-255
            # 1=1, 2=64, 3=128, 4=196, 5=255 (Windows standard mostly)
            val = int((rating / 5.0) * 255)
            
            # POPM frame (Popularimeter)
            # Email can be empty or 'yourparty'
            audio.tags.add(POPM(email='yourparty', rating=val))
            
            # Backup: TXXX:RATING for easier text reading
            audio.tags.add(TXXX(encoding=3, desc='RATING', text=str(rating)))
            
        # 2. Write Mood
        if mood:
            # TXXX:MOOD (Standardish)
            audio.tags.add(TXXX(encoding=3, desc='MOOD', text=mood))
            
            # Also append to Comments for universal compatibility
            # We don't overwrite, we append if not present? 
            # For now, let's just set TXXX, cleaner.
            
        audio.save()
        logger.info(f"Updated ID3 tags for {os.path.basename(file_path)}: Rating={rating}, Mood={mood}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to write ID3 tags: {e}")
        return False
