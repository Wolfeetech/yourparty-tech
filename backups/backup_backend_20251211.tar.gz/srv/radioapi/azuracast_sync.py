#!/usr/bin/env python3
"""
AzuraCast to YourParty Ratings Sync Service

Fetches nowplaying data from AzuraCast API and syncs with YourParty ratings database.
Exports Prometheus metrics for Grafana visualization.
"""
import asyncio
import logging
import os
from datetime import datetime
from typing import Optional, Dict, Any

import httpx
from motor.motor_asyncio import AsyncIOMotorClient
from prometheus_client import Counter, Gauge, start_http_server

# Configuration
AZURACAST_URL = os.getenv("AZURACAST_URL", "http://192.168.178.210")
STATION_ID = os.getenv("AZURACAST_STATION_ID", "1")
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "radioapi")
SYNC_INTERVAL = int(os.getenv("SYNC_INTERVAL", "30"))  # seconds
METRICS_PORT = int(os.getenv("METRICS_PORT", "8081"))
AZURACAST_INSECURE = os.getenv("AZURACAST_INSECURE", "1") in ("1", "true", "True")

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Prometheus metrics
azuracast_listeners = Gauge(
    "azuracast_station_listeners",
    "Current number of listeners on AzuraCast station",
    ["station"]
)
current_track_rating = Gauge(
    "yourparty_current_track_rating",
    "Rating of currently playing track",
    ["song_id", "song_title", "song_artist"]
)
track_rating = Gauge(
    "yourparty_track_rating",
    "Rating of tracked songs",
    ["song_id", "song_title", "song_artist"]
)
sync_success = Counter(
    "azuracast_sync_success_total",
    "Total successful AzuraCast syncs"
)
sync_errors = Counter(
    "azuracast_sync_errors_total",
    "Total AzuraCast sync errors",
    ["error_type"]
)
tracks_synced = Counter(
    "azuracast_tracks_synced_total",
    "Total tracks synced to ratings database"
)


class AzuraCastSync:
    """AzuraCast synchronization service."""
    
    def __init__(self):
        self.mongo_client = AsyncIOMotorClient(MONGODB_URI)
        self.db = self.mongo_client[DB_NAME]
        self.http_client = httpx.AsyncClient(
            timeout=10.0,
            follow_redirects=True,
            verify=not AZURACAST_INSECURE
        )
        self.current_song_id: Optional[str] = None
        
    async def fetch_nowplaying(self) -> Optional[Dict[str, Any]]:
        """Fetch nowplaying data from AzuraCast."""
        try:
            url = f"{AZURACAST_URL}/api/nowplaying/{STATION_ID}"
            logger.debug(f"Fetching nowplaying from {url}")
            response = await self.http_client.get(url)
            response.raise_for_status()
            data = response.json()
            logger.debug(f"Nowplaying response: {data}")
            return data
        except httpx.HTTPError as e:
            logger.error(f"Failed to fetch nowplaying: {e}")
            sync_errors.labels(error_type="http_error").inc()
            return None
        except Exception as e:
            logger.error(f"Unexpected error fetching nowplaying: {e}")
            sync_errors.labels(error_type="unknown").inc()
            return None
    
    async def get_or_create_track_rating(
        self, 
        song_id: str, 
        title: str, 
        artist: str, 
        album: Optional[str] = None
    ) -> Optional[float]:
        """Get existing rating or create placeholder in database."""
        try:
            # Check if track exists in ratings
            rating_doc = await self.db.ratings.find_one({"song_id": song_id})
            
            if rating_doc:
                avg_rating = rating_doc.get("average_rating", 0.0)
                logger.debug(f"Found existing rating for {song_id}: {avg_rating}")
                return avg_rating
            
            # Create placeholder for new track
            track_data = {
                "song_id": song_id,
                "title": title,
                "artist": artist,
                "album": album,
                "average_rating": 0.0,
                "rating_count": 0,
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "source": "azuracast_sync"
            }
            
            await self.db.tracks.update_one(
                {"song_id": song_id},
                {"$set": track_data},
                upsert=True
            )
            
            tracks_synced.inc()
            logger.info(f"Created track placeholder: {title} by {artist}")
            return 0.0
            
        except Exception as e:
            logger.error(f"Database error for track {song_id}: {e}")
            sync_errors.labels(error_type="db_error").inc()
            return None
    
    async def sync_nowplaying(self):
        """Main sync loop."""
        logger.info("Starting AzuraCast sync service")
        
        while True:
            try:
                # Fetch nowplaying data
                nowplaying = await self.fetch_nowplaying()
                
                if not nowplaying:
                    await asyncio.sleep(SYNC_INTERVAL)
                    continue
                
                # Update listener count metric
                listeners = nowplaying.get("listeners", {})
                current_listeners = listeners.get("current", 0)
                azuracast_listeners.labels(station=STATION_ID).set(current_listeners)
                logger.debug(f"Listeners: {current_listeners}")
                
                # Get current track info
                now_playing = nowplaying.get("now_playing", {})
                song = now_playing.get("song", {})
                
                song_id = song.get("id", "")
                title = song.get("title", "Unknown")
                artist = song.get("artist", "Unknown")
                album = song.get("album", "")
                
                if not song_id:
                    logger.warning("No song_id in nowplaying data")
                    await asyncio.sleep(SYNC_INTERVAL)
                    continue
                
                # Only sync if song changed
                if song_id != self.current_song_id:
                    logger.info(f"Track changed: {title} by {artist} (ID: {song_id})")
                    self.current_song_id = song_id
                    
                    # Get or create track rating
                    rating = await self.get_or_create_track_rating(
                        song_id, title, artist, album
                    )
                    
                    if rating is not None:
                        # Update current track rating metric
                        current_track_rating.labels(
                            song_id=song_id,
                            song_title=title,
                            song_artist=artist
                        ).set(rating)
                        
                        # Update track rating metric (for history)
                        track_rating.labels(
                            song_id=song_id,
                            song_title=title,
                            song_artist=artist
                        ).set(rating)
                        
                        logger.info(f"Synced track {song_id} with rating {rating}")
                
                sync_success.inc()
                await asyncio.sleep(SYNC_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error in sync loop: {e}")
                sync_errors.labels(error_type="sync_loop").inc()
                await asyncio.sleep(SYNC_INTERVAL)
    
    async def close(self):
        """Cleanup resources."""
        await self.http_client.aclose()
        self.mongo_client.close()
        logger.info("Closed connections")


async def main():
    """Main entry point."""
    # Start Prometheus metrics server
    start_http_server(METRICS_PORT)
    logger.info(f"Prometheus metrics available at http://localhost:{METRICS_PORT}/metrics")
    
    # Start sync service
    sync_service = AzuraCastSync()
    try:
        await sync_service.sync_nowplaying()
    except KeyboardInterrupt:
        logger.info("Received shutdown signal")
    finally:
        await sync_service.close()


if __name__ == "__main__":
    asyncio.run(main())
