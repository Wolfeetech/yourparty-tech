﻿<?php
/**
 * Front page template for YourParty Tech.
 * DESIGN: IMMERSIVE RADIO (Premium/Club)
 * 
 * @package YourPartyTech
 */

get_header();

$stream_url = apply_filters('yourparty_stream_url', YOURPARTY_STREAM_URL);
?>

<main id="main" class="site-main immersive-mode">
    
    <!-- FULLSCREEN HERO / PLAYER -->
    <section id="hero-player" class="hero-fullscreen">
        
        <!-- BACKGROUND VISUALIZER -->
        <div class="vis-bg-container">
            <!-- ID must match app.js VisualizerController -->
            <canvas id="inline-visualizer"></canvas>
            <div class="vis-overlay-gradient"></div>
        </div>

        <div class="container hero-container">
            
            <!-- TOP BRANDING -->
            <div class="hero-branding" data-aos="fade-down">
                <h1 class="hero-logo">YOURPARTY<span class="highlight">RADIO</span></h1>
                <div class="live-indicator">
                    <span class="pulse-dot"></span> ON AIR
                </div>
            </div>

            <!-- CENTER: THE GLASS PLAYER -->
            <div class="glass-player-wrapper" data-aos="zoom-in" data-aos-duration="1000">
                <div class="glass-player">
                    
                    <!-- Cover Art (Floating) -->
                    <div class="player-cover">
                        <img id="cover-art" src="https://placehold.co/600x600/10b981/ffffff?text=YourParty" alt="Cover" loading="eager">
                        <div class="cover-glow"></div>
                    </div>

                    <!-- Track Info -->
                    <div class="player-info">
                        <h2 id="track-title" class="track-title skeleton">Loading Station...</h2> 
                        <p id="track-artist" class="track-artist skeleton">Please wait</p>
                        
                        <!-- Rating Structure must match rating-module.js -->
                        <div class="rating-strip rating-container">
                            <div class="rating-stars" id="rating-stars" role="radiogroup" aria-label="Rate this track">
                                <button class="rating-star" data-value="1" aria-label="1 star">★</button>
                                <button class="rating-star" data-value="2" aria-label="2 stars">★</button>
                                <button class="rating-star" data-value="3" aria-label="3 stars">★</button>
                                <button class="rating-star" data-value="4" aria-label="4 stars">★</button>
                                <button class="rating-star" data-value="5" aria-label="5 stars">★</button>
                            </div>
                            <span id="rating-average" class="rating-score rating-average" aria-label="Average Rating">--</span>
                        </div>
                    </div>

                    <!-- Mood/Rating Actions -->
                    <div class="player-actions" style="margin: 20px 0; display: flex; gap: 10px; justify-content: center; position: relative; z-index: 9999; pointer-events: auto;">
                         <button id="mood-tag-button" class="btn-glass-small" style="background: rgba(255,255,255,0.15); border-color: rgba(255,255,255,0.3); pointer-events: auto !important; position: relative; z-index: 10000; cursor: pointer;" title="Set Vibe & Genre" aria-label="Open Mood Tagging Dialog" onclick="console.log('INLINE CLICK'); if(window.openMoodDialog){window.openMoodDialog();}else{var d=document.getElementById('mood-dialog');if(d){d.style.display='flex';d.classList.add('active');}else{alert('Mood Dialog loading...');}}">
                            <span style="font-size: 1.2em; vertical-align: middle; margin-right: 5px; pointer-events: none;" aria-hidden="true">🏷️</span> TAG VIBE
                         </button>
                    </div>

                    <!-- Controls -->
                    <div class="player-controls">
                        <button id="mini-play-toggle" class="mini-player__button" aria-label="<?php esc_attr_e('Stream starten', 'yourparty-tech'); ?>">
        <span class="icon-play" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
        </span>
        <span class="icon-pause" style="display:none;" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
        </span>
    </button>
                    </div>

                    <!-- Next Track Preview (Marquee) -->
                    <div class="next-track-preview" aria-live="polite">
                        <span class="label">NEXT:</span>
                        <span id="next-track-marquee">--</span>
                    </div>
                </div>
            </div>

            <!-- BOTTOM: VIBE CONTROL DECK -->
            <div class="vibe-deck" data-aos="fade-up">
                <div class="deck-header">
                    <h3>CONTROL THE VIBE</h3>
                    <div class="deck-line"></div>
                    <!-- VOTE STATUS INDICATOR -->
                    <div id="vibe-status" style="font-size: 0.7rem; color: var(--neon-green); font-weight: bold; white-space: nowrap;" aria-live="polite">AUTO MODE</div>
                </div>
                <div class="vibe-buttons">
                    <button class="vibe-btn" data-vote="energetic" title="More Energy"><span class="emoji">🔥</span> <span class="lbl">ENERGY</span></button>
                    <button class="vibe-btn" data-vote="chill" title="Chill Out"><span class="emoji">🧊</span> <span class="lbl">CHILL</span></button>
                    <button class="vibe-btn" data-vote="groovy" title="Groove"><span class="emoji">🕺</span> <span class="lbl">GROOVE</span></button>
                    <button class="vibe-btn" data-vote="dark" title="Dark Mode"><span class="emoji">🌑</span> <span class="lbl">DARK</span></button>
                </div>
                <div id="vibe-feedback" class="vibe-feedback" aria-live="assertive"></div>
            </div>

        </div>
    </section>

    <!-- HIDDEN AUDIO -->
    <audio id="radio-audio" crossorigin="anonymous" preload="none" style="display:none;">
        <source src="<?php echo esc_url($stream_url); ?>" type="audio/mpeg">
    </audio>

    <!-- SCROLL INDICATOR -->
    <div class="scroll-indicator" data-aos="fade-up" data-aos-delay="1000">
        <span class="mouse-icon"></span>
        <span class="text">DETAILS</span>
    </div>

        <!-- SECONDARY SECTIONS (Revealed on Scroll) -->
    <div id="more-content" class="content-below">
        <div class="container section-spacer">
             <!-- SERVICES / FEATURES -->
             <?php get_template_part('template-parts/sections/services'); ?>
        </div>
        
        <div class="container section-spacer">
             <!-- REFERENCES / TRACK RECORD -->
             <?php get_template_part('template-parts/sections/references'); ?>
        </div>

        <div class="container section-spacer">
             <!-- ABOUT -->
             <?php get_template_part('template-parts/sections/about'); ?>
        </div>

        <div class="container section-spacer">
             <!-- CONTACT -->
             <?php get_template_part('template-parts/sections/contact'); ?>
        </div>
    </div>

</main>

<style>
/* CRITICAL INLINE CSS FOR HERO LAYOUT */
:root {
    --neon-green: #00ff88;
    --neon-blue: #00ccff;
    --glass-bg: rgba(20, 20, 20, 0.65);
    --glass-border: rgba(255, 255, 255, 0.1);
}

body { background: #000; margin: 0; overflow-x: hidden; font-family: 'Inter', sans-serif; color: #eee; }

/* Hero Fullscreen */
.hero-fullscreen {
    position: relative;
    height: 100vh;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

/* Scroll Indicator */
.scroll-indicator {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    opacity: 0.7;
    animation: bounce 2s infinite;
    cursor: pointer;
    z-index: 20;
}
.scroll-indicator .mouse-icon {
    width: 20px; height: 32px; border: 2px solid rgba(255,255,255,0.5); border-radius: 12px; position: relative;
}
.scroll-indicator .mouse-icon::before {
    content: ''; position: absolute; top: 6px; left: 50%; transform: translateX(-50%); width: 4px; height: 4px; background: #fff; border-radius: 50%;
}
.scroll-indicator .text { font-size: 0.7rem; letter-spacing: 0.2em; text-transform: uppercase; }

@keyframes bounce { 0%, 20%, 50%, 80%, 100% {transform: translateX(-50%) translateY(0);} 40% {transform: translateX(-50%) translateY(-10px);} 60% {transform: translateX(-50%) translateY(-5px);} }


/* Background Visualizer */
.vis-bg-container {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    z-index: 1;
}
#inline-visualizer { width: 100%; height: 100%; opacity: 0.4; }
.vis-overlay-gradient {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: radial-gradient(circle at center, transparent 0%, #000 90%);
    pointer-events: none;
}

/* Container */
.hero-container {
    position: relative;
    z-index: 10;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    height: 90vh; /* Keep it constrained so scroll indicator fits */
    width: 100%;
    max-width: 1200px;
    padding: 20px 20px 80px 20px; /* More bottom padding for scroll indicator */
}

/* Branding */
.hero-branding { text-align: center; margin-bottom: 20px; z-index: 20; position: relative; }
.hero-logo { 
    font-size: 3rem; font-weight: 800; letter-spacing: -0.05em; margin: 0; color: #fff; text-shadow: 0 0 30px rgba(255,255,255,0.2); 
    font-family: 'Outfit', sans-serif;
}
.hero-logo .highlight { color: var(--neon-green); }
.live-indicator { 
    font-size: 0.8rem; letter-spacing: 0.3em; color: var(--neon-green); font-weight: bold; margin-top: 10px; display: flex; align-items: center; justify-content: center; gap: 8px;
}
.pulse-dot { width: 8px; height: 8px; background: var(--neon-green); border-radius: 50%; box-shadow: 0 0 10px var(--neon-green); animation: pulse 2s infinite; }

/* Glass Player (Centerpiece) */
.glass-player-wrapper { width: 100%; max-width: 500px; perspective: 1000px; margin-top: -20px; }
.glass-player {
    background: var(--glass-bg);
    backdrop-filter: blur(40px);
    -webkit-backdrop-filter: blur(40px);
    border: 1px solid var(--glass-border);
    border-radius: 30px;
    padding: 40px;
    text-align: center;
    box-shadow: 0 30px 60px rgba(0,0,0,0.8);
    position: relative;
    transition: transform 0.3s ease;
}
/* Album Art */
.player-cover {
    width: 250px; height: 250px; margin: 0 auto 30px; position: relative;
}
.player-cover img {
    width: 100%; height: 100%; object-fit: cover; border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.5);
    position: relative; z-index: 2;
}
.cover-glow { 
    position: absolute; top: 10%; left: 10%; width: 80%; height: 80%; 
    background: var(--neon-green); filter: blur(50px); opacity: 0.4; z-index: 1;
    animation: glow-breathe 4s infinite alternate;
}

/* Info */
.track-title { font-size: 2rem; margin: 0; font-weight: 800; letter-spacing: -0.02em; line-height: 1.1; color: #fff; }
.track-artist { font-size: 1.1rem; color: #aaa; margin: 5px 0 20px; font-weight: 500; }

/* Controls */
.play-fab {
    width: 80px; height: 80px; border-radius: 50%; border: none;
    background: linear-gradient(135deg, var(--neon-green), #00ccaa);
    color: #000; font-size: 30px; cursor: pointer;
    box-shadow: 0 10px 30px rgba(0,255,136,0.3);
    transition: all 0.2s; display: flex; align-items: center; justify-content: center;
    margin: 0 auto 20px;
    z-index: 100;
    position: relative;
}
.play-fab:hover { transform: scale(1.1); box-shadow: 0 0 50px rgba(0,255,136,0.6); }

.btn-glass-small {
    background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2);
    color: #fff; padding: 8px 16px; border-radius: 20px; font-size: 0.75rem;
    cursor: pointer; transition: all 0.2s; font-weight: bold; letter-spacing: 0.05em;
}
.btn-glass-small:hover { background: rgba(255,255,255,0.2); border-color: #fff; }

/* Vibe Deck */
.vibe-deck { width: 100%; max-width: 600px; text-align: center; }
.deck-header { display: flex; align-items: center; gap: 15px; margin-bottom: 15px; }
.deck-header h3 { font-size: 0.8rem; color: #666; letter-spacing: 0.2em; margin: 0; white-space: nowrap; }
.deck-line { width: 100%; height: 1px; background: rgba(255,255,255,0.1); }
.vibe-buttons { display: flex; justify-content: space-between; gap: 10px; }
.vibe-btn {
    flex: 1; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);
    color: #fff; padding: 15px 0; border-radius: 12px; cursor: pointer; transition: all 0.2s;
    display: flex; flex-direction: column; align-items: center; gap: 5px;
}
.vibe-btn:hover { background: rgba(255,255,255,0.1); transform: translateY(-3px); border-color: #fff; }
.vibe-btn .emoji { font-size: 1.5rem; }
.vibe-btn .lbl { font-size: 0.6rem; font-weight: bold; letter-spacing: 0.1em; opacity: 0.7; }

@keyframes glow-breathe { 0% { opacity: 0.3; transform: scale(0.9); } 100% { opacity: 0.6; transform: scale(1.1); } }

/* Next Track Preview */
.next-track-preview {
    margin-top: 15px;
    background: rgba(0,0,0,0.3);
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 0.8rem;
    color: #888;
    display: flex;
    gap: 8px;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    white-space: nowrap;
    border: 1px solid rgba(255,255,255,0.05);
}
.next-track-preview .label {
    color: var(--neon-green);
    font-weight: bold;
    font-size: 0.7rem;
    letter-spacing: 0.1em;
}

/* Rating Stars */
.rating-strip { display: flex; align-items: center; justify-content: center; gap: 15px; margin-bottom: 20px; }
.rating-stars button { background: none; border: none; color: #444; font-size: 24px; cursor: pointer; transition: color 0.1s; padding: 0 2px; }
.rating-stars button:hover, .rating-stars button.active { color: #ffbb00; }
.rating-score { font-size: 1.2rem; font-weight: bold; color: #fff; }

/* Content Below Styling */
.content-below {
    position: relative;
    z-index: 10;
    background: #050505;
    background: linear-gradient(to bottom, #000 0%, #0a0a0a 100%);
    padding-top: 50px;
}
.section-spacer { padding: 40px 20px; border-bottom: 1px solid rgba(255,255,255,0.05); }

/* Mobile */
@media(max-width: 600px) {
    .glass-player { padding: 20px; }
    .player-cover { width: 180px; height: 180px; }
    .track-title { font-size: 1.5rem; }
    .vibe-buttons { display: grid; grid-template-columns: 1fr 1fr; }
    .hero-container { padding-bottom: 100px; } 
}

/* === MOOD DIALOG STYLES MOVED TO assets/mood-dialog.css === */
</style>

<!-- MOOD DIALOG (Professional Implementation) -->
<div id="mood-dialog" class="mood-dialog" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; z-index:99999; align-items:center; justify-content:center;">
    <div id="mood-backdrop" onclick="document.getElementById('mood-dialog').style.display='none';" style="position:absolute; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); backdrop-filter:blur(10px); z-index:1;"></div>
    <div class="mood-dialog-content" style="position:relative; z-index:10; background:linear-gradient(180deg, rgba(30,30,30,0.98) 0%, rgba(15,15,15,0.98) 100%); border:1px solid rgba(255,255,255,0.15); box-shadow:0 25px 80px rgba(0,0,0,0.9); border-radius:24px; padding:32px; width:90%; max-width:480px; text-align:center; color:#fff;">
        <button id="mood-close" onclick="document.getElementById('mood-dialog').style.display='none';" style="position:absolute; top:16px; right:16px; background:rgba(255,255,255,0.1); border:none; color:#fff; font-size:1.3rem; cursor:pointer; width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center; transition:all 0.2s;">&times;</button>
        
        <h3 style="font-size:1.4rem; margin:0 0 8px 0; font-weight:700;">🏷️ Tag This Vibe</h3>
        <p id="mood-track-info" style="color:#888; margin:0 0 24px 0; font-size:0.85rem;">How does this track make you feel?</p>
        
        <div id="mood-grid" style="display:grid; grid-template-columns:repeat(4, 1fr); gap:10px; margin-bottom:24px;">
            <button class="mood-option" data-mood="energetic" style="background:rgba(255,255,255,0.05); border:2px solid rgba(255,255,255,0.1); padding:14px 8px; border-radius:12px; cursor:pointer; color:#fff; display:flex; flex-direction:column; align-items:center; gap:6px; transition:all 0.2s;">
                <span style="font-size:1.6rem;">⚡</span><span style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Energetic</span>
            </button>
            <button class="mood-option" data-mood="chill" style="background:rgba(255,255,255,0.05); border:2px solid rgba(255,255,255,0.1); padding:14px 8px; border-radius:12px; cursor:pointer; color:#fff; display:flex; flex-direction:column; align-items:center; gap:6px; transition:all 0.2s;">
                <span style="font-size:1.6rem;">🌴</span><span style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Chill</span>
            </button>
            <button class="mood-option" data-mood="euphoric" style="background:rgba(255,255,255,0.05); border:2px solid rgba(255,255,255,0.1); padding:14px 8px; border-radius:12px; cursor:pointer; color:#fff; display:flex; flex-direction:column; align-items:center; gap:6px; transition:all 0.2s;">
                <span style="font-size:1.6rem;">🤩</span><span style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Euphoric</span>
            </button>
            <button class="mood-option" data-mood="dark" style="background:rgba(255,255,255,0.05); border:2px solid rgba(255,255,255,0.1); padding:14px 8px; border-radius:12px; cursor:pointer; color:#fff; display:flex; flex-direction:column; align-items:center; gap:6px; transition:all 0.2s;">
                <span style="font-size:1.6rem;">🌑</span><span style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Dark</span>
            </button>
            <button class="mood-option" data-mood="groovy" style="background:rgba(255,255,255,0.05); border:2px solid rgba(255,255,255,0.1); padding:14px 8px; border-radius:12px; cursor:pointer; color:#fff; display:flex; flex-direction:column; align-items:center; gap:6px; transition:all 0.2s;">
                <span style="font-size:1.6rem;">💃</span><span style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Groovy</span>
            </button>
            <button class="mood-option" data-mood="melodic" style="background:rgba(255,255,255,0.05); border:2px solid rgba(255,255,255,0.1); padding:14px 8px; border-radius:12px; cursor:pointer; color:#fff; display:flex; flex-direction:column; align-items:center; gap:6px; transition:all 0.2s;">
                <span style="font-size:1.6rem;">🎹</span><span style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Melodic</span>
            </button>
            <button class="mood-option" data-mood="hypnotic" style="background:rgba(255,255,255,0.05); border:2px solid rgba(255,255,255,0.1); padding:14px 8px; border-radius:12px; cursor:pointer; color:#fff; display:flex; flex-direction:column; align-items:center; gap:6px; transition:all 0.2s;">
                <span style="font-size:1.6rem;">🌀</span><span style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Hypnotic</span>
            </button>
            <button class="mood-option" data-mood="uplifting" style="background:rgba(255,255,255,0.05); border:2px solid rgba(255,255,255,0.1); padding:14px 8px; border-radius:12px; cursor:pointer; color:#fff; display:flex; flex-direction:column; align-items:center; gap:6px; transition:all 0.2s;">
                <span style="font-size:1.6rem;">🚀</span><span style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Uplifting</span>
            </button>
        </div>
        
        <div id="mood-status" style="min-height:20px; margin-bottom:12px; font-size:0.8rem; color:#888;"></div>
        
        <button id="mood-submit-btn" disabled style="background:linear-gradient(135deg, #00ff88 0%, #00cc6a 100%); color:#000; padding:16px 32px; border:none; border-radius:30px; font-weight:700; font-size:1rem; cursor:pointer; width:100%; transition:all 0.3s; opacity:0.5; text-transform:uppercase; letter-spacing:0.05em;">Select a Vibe First</button>
    </div>
</div>

<script>
(function() {
    'use strict';
    
    // State
    let selectedMood = null;
    let currentSongId = null;
    
    // Fetch current song ID from AzuraCast status API
    async function fetchCurrentSongId() {
        try {
            const response = await fetch('/wp-json/yourparty/v1/status');
            if (!response.ok) return;
            const data = await response.json();
            const songId = data?.now_playing?.song?.id;
            if (songId) {
                window.currentSongId = songId;
                console.log('[MoodDialog] Fetched song ID from API:', songId);
            }
        } catch (e) {
            console.warn('[MoodDialog] Failed to fetch song ID:', e);
        }
    }
    
    // Fetch immediately and every 15 seconds
    fetchCurrentSongId();
    setInterval(fetchCurrentSongId, 15000);
    
    // DOM Elements
    const dialog = document.getElementById('mood-dialog');
    const backdrop = document.getElementById('mood-backdrop');
    const closeBtn = document.getElementById('mood-close');
    const submitBtn = document.getElementById('mood-submit-btn');
    const statusEl = document.getElementById('mood-status');
    const trackInfo = document.getElementById('mood-track-info');
    const moodOptions = document.querySelectorAll('.mood-option');
    const tagButton = document.getElementById('mood-tag-button');
    
    // Open Dialog
    function openDialog() {
        console.log('[MoodDialog] Opening...');
        selectedMood = null;
        updateSubmitButton();
        
        // Reset all selections
        moodOptions.forEach(btn => {
            btn.style.background = 'rgba(255,255,255,0.05)';
            btn.style.borderColor = 'rgba(255,255,255,0.1)';
            btn.style.transform = 'scale(1)';
        });
        
        // Get current track info
        const title = document.getElementById('track-title')?.textContent || 'Current Track';
        const artist = document.getElementById('track-artist')?.textContent || '';
        trackInfo.textContent = artist ? `${artist} - ${title}` : title;
        
        // Try to get song ID from global state (status-fix.js sets window.currentSongId)
        if (window.currentSongId) {
            currentSongId = window.currentSongId;
            console.log('[MoodDialog] Using window.currentSongId:', currentSongId);
        } else if (window.YourPartyAppInstance?.currentSongId) {
            currentSongId = window.YourPartyAppInstance.currentSongId;
            console.log('[MoodDialog] Using YourPartyAppInstance.currentSongId:', currentSongId);
        } else {
            // Fallback - should rarely happen if status is loaded
            currentSongId = 'unknown_' + Date.now();
            console.warn('[MoodDialog] No song ID available, using fallback:', currentSongId);
        }
        
        statusEl.textContent = '';
        dialog.style.display = 'flex';
        dialog.classList.add('active');
    }
    
    // Close Dialog
    function closeDialog() {
        console.log('[MoodDialog] Closing...');
        dialog.style.display = 'none';
        dialog.classList.remove('active');
    }
    
    // Update Submit Button
    function updateSubmitButton() {
        if (selectedMood) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.textContent = 'Submit Vote ✓';
        } else {
            submitBtn.disabled = true;
            submitBtn.style.opacity = '0.5';
            submitBtn.textContent = 'Select a Vibe First';
        }
    }
    
    // Handle Mood Selection
    function selectMood(btn, mood) {
        console.log('[MoodDialog] Selected:', mood);
        selectedMood = mood;
        
        // Visual feedback - reset all
        moodOptions.forEach(b => {
            b.style.background = 'rgba(255,255,255,0.05)';
            b.style.borderColor = 'rgba(255,255,255,0.1)';
            b.style.transform = 'scale(1)';
            b.style.boxShadow = 'none';
        });
        
        // Highlight selected
        btn.style.background = 'linear-gradient(135deg, rgba(0,255,136,0.3) 0%, rgba(0,200,100,0.2) 100%)';
        btn.style.borderColor = '#00ff88';
        btn.style.transform = 'scale(1.05)';
        btn.style.boxShadow = '0 0 20px rgba(0,255,136,0.3)';
        
        updateSubmitButton();
    }
    
    // Submit Vote
    async function submitVote() {
        if (!selectedMood) return;
        
        console.log('[MoodDialog] Submitting vote:', selectedMood, 'for song:', currentSongId);
        
        submitBtn.disabled = true;
        submitBtn.textContent = 'Sending...';
        statusEl.textContent = '';
        statusEl.style.color = '#888';
        
        try {
            // Get title/artist for track metadata
            const title = document.getElementById('track-title')?.textContent || 'Unknown';
            const artist = document.getElementById('track-artist')?.textContent || 'Unknown';
            
            const payload = {
                song_id: currentSongId,
                mood_current: selectedMood,
                title: title,
                artist: artist
            };
            
            const restBase = window.YourPartyConfig?.restBase || '/wp-json/yourparty/v1';
            const response = await fetch(restBase + '/vote-mood', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            
            if (response.ok) {
                statusEl.textContent = '✓ Vote recorded!';
                statusEl.style.color = '#00ff88';
                submitBtn.textContent = 'Done!';
                
                setTimeout(closeDialog, 1200);
            } else {
                const err = await response.text();
                console.error('[MoodDialog] API Error:', err);
                statusEl.textContent = 'Error: ' + (response.status === 503 ? 'Service unavailable' : 'Try again');
                statusEl.style.color = '#ff4444';
                submitBtn.textContent = 'Retry';
                submitBtn.disabled = false;
            }
        } catch (e) {
            console.error('[MoodDialog] Network error:', e);
            statusEl.textContent = 'Network error - vote saved locally';
            statusEl.style.color = '#ffaa00';
            
            // Queue for later
            const queue = JSON.parse(localStorage.getItem('yp_vote_queue') || '[]');
            queue.push({ song_id: currentSongId, mood_current: selectedMood, timestamp: Date.now() });
            localStorage.setItem('yp_vote_queue', JSON.stringify(queue));
            
            setTimeout(closeDialog, 1500);
        }
    }
    
    // Event Bindings
    if (tagButton) {
        tagButton.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            openDialog();
        });
    }
    
    if (backdrop) backdrop.addEventListener('click', closeDialog);
    if (closeBtn) closeBtn.addEventListener('click', closeDialog);
    if (submitBtn) submitBtn.addEventListener('click', submitVote);
    
    moodOptions.forEach(btn => {
        btn.addEventListener('click', function() {
            selectMood(this, this.dataset.mood);
        });
        
        // Hover effects
        btn.addEventListener('mouseenter', function() {
            if (this.dataset.mood !== selectedMood) {
                this.style.background = 'rgba(255,255,255,0.1)';
                this.style.borderColor = 'rgba(255,255,255,0.3)';
            }
        });
        btn.addEventListener('mouseleave', function() {
            if (this.dataset.mood !== selectedMood) {
                this.style.background = 'rgba(255,255,255,0.05)';
                this.style.borderColor = 'rgba(255,255,255,0.1)';
            }
        });
    });
    
    // Close on Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && dialog.style.display === 'flex') {
            closeDialog();
        }
    });
    
    // Global function - override MoodModule.js with delay to ensure we win
    window.openMoodDialog = openDialog;
    
    // Re-override after modules load (MoodModule.js overwrites this)
    setTimeout(function() {
        window.openMoodDialog = openDialog;
        console.log('[MoodDialog] Re-claimed window.openMoodDialog');
    }, 500);
    
    // And again after longer delay just in case
    setTimeout(function() {
        window.openMoodDialog = openDialog;
    }, 2000);
    
    console.log('[MoodDialog] Initialized');
})();
</script>

<?php get_footer(); ?>
